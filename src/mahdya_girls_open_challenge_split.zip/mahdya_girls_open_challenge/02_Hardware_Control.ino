// ==========================================================
// DFRobot FIT0186 ENCODER - DISTANCE CORRECTED
// ==========================================================
//
// Encoder A -> Mega D2, interrupt on RISING only.
// Encoder B -> Mega D3, used only to determine direction.
//
// WHY RISING INSTEAD OF CHANGE:
// The FIT0186 is specified at approximately 700 encoder counts per
// gearbox-output revolution. Counting both edges of A with CHANGE
// can effectively double the transition count for distance measurement
// and make the robot stop before the commanded distance.
//
// Physical forward previously counted negative on this robot, therefore
// ENCODER_DIRECTION is set to -1 so forward encoder ticks are positive.
void encoderISR() {
  bool b =
    digitalRead(
      PIN_ENCODER_B
    );

  if (b)
    encoderTicks += ENCODER_DIRECTION;
  else
    encoderTicks -= ENCODER_DIRECTION;
}
long getEncoderTicks() {
  noInterrupts();
  long v = encoderTicks;
  interrupts();
  return v;
}
void resetEncoderTicks() {
  noInterrupts(); encoderTicks = 0; interrupts();
}
float encoderCountsPerCM() {
  float c = PI * WHEEL_DIAMETER_CM;
  return (c > 0.0) ? ENCODER_COUNTS_PER_WHEEL_REV / c : 1.0;
}
float encoderDistanceCMFrom(long startTicks) {
  return (float)labs(getEncoderTicks() - startTicks) / encoderCountsPerCM();
}

// ===================== MOTOR =====================
int lastMotorCommand = 0;
void setMotor(int command) {
  command = constrain(command, -255, 255) * MOTOR_DIRECTION;
  lastMotorCommand = command;
  if (command > 0) {
    analogWrite(PIN_BTS_RPWM, command);
    analogWrite(PIN_BTS_LPWM, 0);
  } else if (command < 0) {
    analogWrite(PIN_BTS_RPWM, 0);
    analogWrite(PIN_BTS_LPWM, -command);
  } else {
    analogWrite(PIN_BTS_RPWM, 0);
    analogWrite(PIN_BTS_LPWM, 0);
  }
}
void stopMotor() { setMotor(0); }

// ===================== STEERING =====================
float lastSteeringCommand = 0.0;
void setSteering(float commandDeg) {
  commandDeg = constrain(commandDeg, -MAX_STEER_DEG, +MAX_STEER_DEG);
  lastSteeringCommand = commandDeg;
  float angle = SERVO_CENTER_DEG + SERVO_DIRECTION * commandDeg;
  angle = constrain(angle, 0.0, 180.0);
  steeringServo.write((int)angle);
}
void centerSteering() { setSteering(0.0); }

// ===================== BUZZER =====================
void buzzerStart()        { tone(PIN_BUZZER, 2200, 90); }

// Two-tone signal: initialization is complete and robot is waiting
// for the physical START button.
void buzzerReady() {
  tone(PIN_BUZZER, 2400, 120);
  delay(160);
  tone(PIN_BUZZER, 3000, 180);
  delay(220);
}
void buzzerBlue()         { tone(PIN_BUZZER, 2600, 90); }
void buzzerOrange()       { tone(PIN_BUZZER, 1800, 90); }
void buzzerTurnComplete() { tone(PIN_BUZZER, 2900, 90); }
void buzzerFinish()       { tone(PIN_BUZZER, 3200, 300); }
void buzzerStuck()        { tone(PIN_BUZZER, 900, 250); }
unsigned long lastTurnBuzzerMs = 0;
void buzzerTurningTick() {
  if (millis() - lastTurnBuzzerMs >= 250) {
    lastTurnBuzzerMs = millis();
    tone(PIN_BUZZER, 1500, 25);
  }
}

// ===================== ULTRASONIC =====================
//
// Existing:
//   frontCM, leftCM, rightCM, rearCM
//
// New:
//   rearLeftCM, rearRightCM
//
// The new rear-side sensors should point SIDEWAYS and be mounted
// close to / just ahead of the widest rear-wheel area.
float frontCM = 999.0;
float leftCM = 999.0;
float rightCM = 999.0;
float rearCM = 999.0;
float rearLeftCM = 999.0;
float rearRightCM = 999.0;

float readURM09(uint8_t pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
  delayMicroseconds(2);
  digitalWrite(pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(pin, LOW);
  pinMode(pin, INPUT);

  uint32_t pulseWidthUs =
    pulseIn(
      pin,
      HIGH,
      URM09_PULSE_TIMEOUT_US
    );

  if (pulseWidthUs == 0)
    return -1.0;

  float distance =
    pulseWidthUs *
    VELOCITY_TEMP(ULTRASONIC_TEMP_C) /
    2.0;

  if (
    distance < 2.0 ||
    distance > 500.0
  ) {
    return -1.0;
  }

  return distance;
}

float filterSonar(
  float oldValue,
  float newValue
) {
  if (newValue < 0.0)
    return oldValue;

  if (oldValue > 500.0)
    return newValue;

  return
    oldValue *
      SONAR_FILTER_OLD_WEIGHT +
    newValue *
      (1.0 - SONAR_FILTER_OLD_WEIGHT);
}

uint8_t sonarSlot = 0;
unsigned long lastSonarSlotMs = 0;

void updateUltrasonics() {
  if (
    millis() -
    lastSonarSlotMs <
    SONAR_SLOT_INTERVAL_MS
  ) {
    return;
  }

  lastSonarSlotMs =
    millis();

  float m = -1.0;

  switch (sonarSlot) {
    case 0:
      m = readURM09(PIN_US_FRONT);
      frontCM = filterSonar(frontCM, m);
      break;

    case 1:
      m = readURM09(PIN_US_LEFT);
      leftCM = filterSonar(leftCM, m);
      break;

    case 2:
      m = readURM09(PIN_US_RIGHT);
      rightCM = filterSonar(rightCM, m);
      break;

    case 3:
      m = readURM09(PIN_US_REAR_LEFT);
      rearLeftCM = filterSonar(rearLeftCM, m);
      break;

    case 4:
      m = readURM09(PIN_US_REAR_RIGHT);
      rearRightCM = filterSonar(rearRightCM, m);
      break;

    case 5:
      m = readURM09(PIN_US_REAR);
      rearCM = filterSonar(rearCM, m);
      break;
  }

  sonarSlot =
    (sonarSlot + 1) % 6;
}

void readAllUltrasonicsNow() {
  float v;

  v = readURM09(PIN_US_FRONT);
  if (v > 0) frontCM = v;
  delay(18);

  v = readURM09(PIN_US_LEFT);
  if (v > 0) leftCM = v;
  delay(18);

  v = readURM09(PIN_US_RIGHT);
  if (v > 0) rightCM = v;
  delay(18);

  v = readURM09(PIN_US_REAR_LEFT);
  if (v > 0) rearLeftCM = v;
  delay(18);

  v = readURM09(PIN_US_REAR_RIGHT);
  if (v > 0) rearRightCM = v;
  delay(18);

  v = readURM09(PIN_US_REAR);
  if (v > 0) rearCM = v;
}

// ===================== MPU6050 / YAW =====================
// Uses the exact Adafruit MPU6050 method that already worked
// on your Arduino Mega.

float currentYaw = 0.0;
float targetYaw = 0.0;

float latestAccelX = 0.0;
float latestAccelY = 0.0;
float latestAccelZ = 0.0;

float latestGyroX = 0.0;
float latestGyroY = 0.0;
float latestGyroZ = 0.0;

float latestMPUTempC = 0.0;

unsigned long lastIMUMicros = 0;
unsigned long lastIMUReadMicros = 0;

float previousCorrectedGyroZ = 0.0;
bool havePreviousGyroSample = false;

bool initializeIMU() {
  Serial.println(F("# Starting MPU6050..."));

  // Same simple begin() method from your working test.
  if (!mpu.begin()) {
    imuOK = false;
    Serial.println(F("# MPU6050 begin FAILED"));
    return false;
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  // 4-wheel steering produces a much faster yaw rate.
  // Use +/-2000 dps so the turn gyro does not saturate.
  mpu.setGyroRange(MPU6050_RANGE_2000_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  delay(100);

  imuOK = true;
  Serial.println(F("# MPU6050 CONNECTED"));

  return true;
}

bool readIMUData() {
  if (!imuOK)
    return false;

  sensors_event_t a, g, temp;

  if (!mpu.getEvent(&a, &g, &temp))
    return false;

  latestAccelX = a.acceleration.x;
  latestAccelY = a.acceleration.y;
  latestAccelZ = a.acceleration.z;

  // Adafruit returns rad/s. Convert to deg/s.
  latestGyroX = g.gyro.x * 180.0 / PI;
  latestGyroY = g.gyro.y * 180.0 / PI;
  latestGyroZ = g.gyro.z * 180.0 / PI;

  latestMPUTempC = temp.temperature;

  return true;
}

bool readGyroZ(float &gz) {
  if (!readIMUData())
    return false;

  gz = latestGyroZ;
  return true;
}

void calibrateGyroQuick() {
  if (!imuOK)
    return;

  Serial.println(F("# MPU CALIBRATION - KEEP ROBOT STILL"));

  float sum = 0.0;
  uint16_t good = 0;

  for (uint16_t i = 0; i < QUICK_GYRO_SAMPLES; i++) {
    float gz;

    if (readGyroZ(gz)) {
      sum += gz;
      good++;
    }

    delay(QUICK_GYRO_DELAY_MS);
  }

  if (good > 0)
    GYRO_Z_BIAS_DPS = sum / (float)good;
  else
    GYRO_Z_BIAS_DPS = 0.0;

  currentYaw = 0.0;

  lastIMUMicros = micros();
  lastIMUReadMicros = lastIMUMicros;

  previousCorrectedGyroZ = 0.0;
  havePreviousGyroSample = false;

  Serial.print(F("# MPU GYRO_Z_BIAS="));
  Serial.println(GYRO_Z_BIAS_DPS, 5);
}

void resetYaw() {
  currentYaw = 0.0;
  targetYaw = 0.0;

  unsigned long now = micros();

  lastIMUMicros = now;
  lastIMUReadMicros = now;

  previousCorrectedGyroZ = 0.0;
  havePreviousGyroSample = false;
}

void updateYaw() {
  if (!imuOK)
    return;

  unsigned long scheduleNow = micros();

  // Rate limit only when the loop is running very fast.
  if ((unsigned long)(scheduleNow - lastIMUReadMicros) <
      IMU_READ_INTERVAL_US)
    return;

  lastIMUReadMicros = scheduleNow;

  float gz;

  if (!readGyroZ(gz))
    return;

  // Timestamp AFTER the sensor read.
  unsigned long now = micros();

  float correctedGyroZ =
    gz - GYRO_Z_BIAS_DPS;

  // Remove only very small stationary noise.
  if (fabs(correctedGyroZ) < YAW_GYRO_DEADBAND_DPS)
    correctedGyroZ = 0.0;

  if (!havePreviousGyroSample) {
    previousCorrectedGyroZ = correctedGyroZ;
    havePreviousGyroSample = true;
    lastIMUMicros = now;
    return;
  }

  float dt =
    (float)(now - lastIMUMicros) /
    1000000.0f;

  lastIMUMicros = now;

  // In the full robot, UART/ultrasonic operations can make dt larger
  // than in the standalone MPU test. Do NOT throw away a normal
  // 100-300 ms interval, otherwise yaw loses part of the turn.
  //
  // Ignore only an abnormally huge pause.
  if (dt <= 0.0f || dt > 0.50f) {
    previousCorrectedGyroZ = correctedGyroZ;
    return;
  }

  // Trapezoidal integration:
  // use both the previous and current gyro samples.
  // This is much more accurate when the main loop has uneven timing.
  float averageGyroZ =
    0.5f *
    (previousCorrectedGyroZ + correctedGyroZ);

  // IMPORTANT:
  // currentYaw must use ONE consistent scale in corridors AND corners.
  // Never multiply the main yaw only during a corner, otherwise after
  // the turn the controller can believe the robot is aligned when the
  // physical chassis is not aligned.
  currentYaw +=
    YAW_SIGN *
    YAW_SCALE *
    averageGyroZ *
    dt;

  previousCorrectedGyroZ =
    correctedGyroZ;
}

// ===================== CORRIDOR CONTROL =====================
float previousYawError = 0.0;
unsigned long lastControlMicros = 0;

bool validSideDistance(float cm) {
  return
    cm >= SIDE_VALID_MIN_CM &&
    cm <= SIDE_VALID_MAX_CM;
}

bool validTurnOpeningDistance(float cm) {
  return
    cm > 0.0 &&
    cm < 500.0;
}

void resetFourWheelStableController() {
  // Seed derivative from the CURRENT yaw error.
  // This avoids a derivative spike when entering a new corridor.
  previousYawError =
    targetYaw -
    currentYaw;

  lastControlMicros =
    micros();

  fourWsFilteredWallError = 0.0;
  fourWsFilteredWanted = 0.0;
  fourWsFilteredSteer = 0.0;
  fourWsLastRawSteer = 0.0;
  fourWsLastHeadingCorrection = 0.0;
  fourWsLastSteerMicros = micros();

  lastWallCorrectionDeg = 0.0;
  wallAvoidActive = false;
}

float headingCorrection() {
  float error =
    targetYaw -
    currentYaw;

  if (
    fabs(error) <=
    FOUR_WS_YAW_DEADBAND_DEG
  ) {
    error =
      0.0;
  }

  unsigned long now =
    micros();

  float dt =
    (float)(
      now -
      lastControlMicros
    ) /
    1000000.0f;

  if (
    dt <= 0.0f ||
    dt > 0.20f
  ) {
    dt =
      0.02f;
  }

  lastControlMicros =
    now;

  float derivative =
    (
      error -
      previousYawError
    ) /
    dt;

  previousYawError =
    error;

  float correction =
    -(
      YAW_KP *
        error +
      YAW_KD *
        derivative
    );

  correction =
    constrain(
      correction,
      -CORRIDOR_MAX_STEER_DEG,
      +CORRIDOR_MAX_STEER_DEG
    );

  fourWsLastHeadingCorrection =
    correction;

  return correction;
}

float wallCorrection() {
  bool leftValid =
    validSideDistance(
      leftCM
    );

  bool rightValid =
    validSideDistance(
      rightCM
    );

  wallAvoidActive =
    false;

  // ========================================================
  // WALL AVOID ONLY
  // ========================================================
  //
  // There is NO ultrasonic centering anymore.
  //
  // Side ultrasonics are ignored unless a wall is closer than
  // WALL_AVOID_TRIGGER_CM (10 cm).
  //
  // If both sides are below 10 cm, move away from the closer wall.
  bool leftDanger =
    leftValid &&
    leftCM <
      WALL_AVOID_TRIGGER_CM;

  bool rightDanger =
    rightValid &&
    rightCM <
      WALL_AVOID_TRIGGER_CM;

  if (
    leftDanger &&
    rightDanger
  ) {
    wallAvoidActive =
      true;

    if (leftCM < rightCM) {
      // Left wall is closer -> steer RIGHT.
      lastWallCorrectionDeg =
        +WALL_AVOID_STEER_DEG;
    }
    else {
      // Right wall is closer -> steer LEFT.
      lastWallCorrectionDeg =
        -WALL_AVOID_STEER_DEG;
    }

    return
      lastWallCorrectionDeg;
  }

  if (leftDanger) {
    wallAvoidActive =
      true;

    lastWallCorrectionDeg =
      +WALL_AVOID_STEER_DEG;

    return
      lastWallCorrectionDeg;
  }

  if (rightDanger) {
    wallAvoidActive =
      true;

    lastWallCorrectionDeg =
      -WALL_AVOID_STEER_DEG;

    return
      lastWallCorrectionDeg;
  }

  // Normal corridor:
  // NO ultrasonic steering at all.
  lastWallCorrectionDeg =
    0.0;

  return 0.0;
}

float applyFourWheelSteerSmoothing(
  float rawCommand
) {
  rawCommand =
    constrain(
      rawCommand,
      -CORRIDOR_MAX_STEER_DEG,
      +CORRIDOR_MAX_STEER_DEG
    );

  fourWsLastRawSteer =
    rawCommand;

  fourWsFilteredWanted =
    FOUR_WS_COMMAND_FILTER *
      fourWsFilteredWanted +
    (
      1.0 -
      FOUR_WS_COMMAND_FILTER
    ) *
      rawCommand;

  float wantedOutput =
    fourWsFilteredWanted;

  if (
    fabs(
      wantedOutput
    ) <
    FOUR_WS_OUTPUT_DEADBAND_DEG
  ) {
    wantedOutput =
      0.0;
  }

  unsigned long now =
    micros();

  float dt =
    (float)(
      now -
      fourWsLastSteerMicros
    ) /
    1000000.0f;

  if (
    dt <= 0.0f ||
    dt > 0.20f
  ) {
    dt =
      0.02f;
  }

  fourWsLastSteerMicros =
    now;

  float maxStep =
    FOUR_WS_STEER_SLEW_DPS *
      dt;

  float delta =
    wantedOutput -
    fourWsFilteredSteer;

  delta =
    constrain(
      delta,
      -maxStep,
      +maxStep
    );

  fourWsFilteredSteer +=
    delta;

  if (
    wantedOutput == 0.0 &&
    fabs(
      fourWsFilteredSteer
    ) <
    0.15f
  ) {
    fourWsFilteredSteer =
      0.0;
  }

  return
    fourWsFilteredSteer;
}

float corridorSteering() {
  // --------------------------------------------------------
  // PREVENT CUMULATIVE GYRO DRIFT
  // --------------------------------------------------------
  //
  // Only rebase when:
  //   1) we already spent some time in the new corridor, and
  //   2) the measured error is already very small.
  //
  // Large heading errors are NEVER hidden.
  if (
    corridorYawRebasePending &&
    millis() >=
      corridorYawRebaseEarliestMs
  ) {
    float rebaseError =
      targetYaw -
      currentYaw;

    if (
      fabs(
        rebaseError
      ) <=
      CORRIDOR_YAW_REBASE_MAX_ERROR_DEG
    ) {
      currentYaw =
        targetYaw;

      previousCorrectedGyroZ =
        0.0;

      havePreviousGyroSample =
        false;

      lastIMUMicros =
        micros();

      lastIMUReadMicros =
        lastIMUMicros;

      previousYawError =
        0.0;

      corridorYawRebasePending =
        false;

      Serial.print(F("# YAW REBASE target="));
      Serial.println(targetYaw, 2);
    }
  }

  float yawPart =
    headingCorrection();

  // Returns zero normally.
  // Only returns a steering command if left/right wall is <10 cm.
  float wallAvoidPart =
    wallCorrection();

  float raw =
    yawPart +
    wallAvoidPart;

  return
    applyFourWheelSteerSmoothing(
      raw
    );
}

// Open-challenge final straight: yaw correction only, no wall centering.
float stableYawOnlySteering(
  float wantedYaw
) {
  float savedTarget =
    targetYaw;

  targetYaw =
    wantedYaw;

  float raw =
    headingCorrection();

  targetYaw =
    savedTarget;

  return
    applyFourWheelSteerSmoothing(
      raw
    );
}

// ===================== HUSKYLENS =====================
bool initializeHusky() {
  // HUSKYLENS is NOT on I2C anymore.
  // Mega hardware UART:
  // RX1 = D19
  // TX1 = D18
  Serial1.begin(9600);

  delay(500);

  huskyOK =
    huskylens.begin(
      Serial1
    );

  if (!huskyOK)
    return false;

  huskyOK =
    huskylens.switchAlgorithm(
      ALGORITHM_COLOR_RECOGNITION
    );

  return huskyOK;
}

int huskyResultCount = 0;
int huskyLearnedCount = 0;
int huskyBestLearnedID = 0;
int huskyBestX = 0, huskyBestY = 0, huskyBestW = 0, huskyBestH = 0;
int huskyBestIntersectionDirection = 0;
unsigned long lastHuskyPollMs = 0;
unsigned long lastGoodHuskyFrameMs = 0;

// Best valid RED/GREEN pillar from the latest HUSKYLENS frame.
int huskyBestPillarID = 0;
int huskyBestPillarX = 0;
int huskyBestPillarY = 0;
int huskyBestPillarW = 0;
int huskyBestPillarH = 0;
long huskyBestPillarArea = 0;
unsigned long lastGoodPillarFrameMs = 0;

// Smart pillar confidence. Avoidance does not start from one noisy frame.
int pillarConfidenceScore = 0;
int pillarConfidenceID = 0;
int pillarConfidencePrevX = 0;
int pillarConfidencePrevBottomY = 0;
long pillarConfidencePrevArea = 0;

void updateHusky() {
  if (!huskyOK) return;
  if (millis() - lastHuskyPollMs < HUSKY_POLL_INTERVAL_MS) return;
  lastHuskyPollMs = millis();

  // Actual current DFRobot source: -1 means communication failure,
  // 0 means no results, >0 means number of returned results.
  int8_t count = huskylens.getResult(ALGORITHM_COLOR_RECOGNITION);

  if (count < 0) {
    huskyOK = false;
    huskyResultCount = -1;
    huskyLearnedCount = 0;
    huskyBestLearnedID = 0;
    huskyBestIntersectionDirection = 0;

    huskyBestPillarID = 0;
    huskyBestPillarX = 0;
    huskyBestPillarY = 0;
    huskyBestPillarW = 0;
    huskyBestPillarH = 0;
    huskyBestPillarArea = 0;

    pillarConfidenceScore = 0;
    pillarConfidenceID = 0;

    return;
  }

  huskyResultCount = count;
  huskyLearnedCount =
    huskylens.getCachedResultLearnedNum(
      ALGORITHM_COLOR_RECOGNITION
    );

  huskyBestLearnedID = 0;
  huskyBestX = 0;
  huskyBestY = 0;
  huskyBestW = 0;
  huskyBestH = 0;
  huskyBestIntersectionDirection = 0;

  // Build the best pillar for THIS frame locally. If one frame is
  // missed, keep the last valid pillar briefly instead of flickering
  // instantly to NONE.
  int frameBestPillarID = 0;
  int frameBestPillarX = 0;
  int frameBestPillarY = 0;
  int frameBestPillarW = 0;
  int frameBestPillarH = 0;
  long frameBestPillarArea = 0;

  long bestLearnedScore = -1;
  long bestIntersectionScore = -1;

  // Nearest pillar selection:
  // 1) largest box area wins
  // 2) if areas are equal, the box lower in the image wins
  long bestPillarArea = -1;
  int bestPillarBottomY = -1;

  while (huskylens.available(ALGORITHM_COLOR_RECOGNITION)) {
    Result *r =
      huskylens.popCachedResult(
        ALGORITHM_COLOR_RECOGNITION
      );

    if (r == NULL) break;

    // ID 0 = white/unlearned box. Ignore completely.
    if (r->ID == 0) continue;

    long area =
      (long)r->width *
      (long)r->height;

    // Objects lower in the frame receive a larger score because
    // they are generally closer to the robot.
    long score =
      (long)r->yCenter * 3L +
      (long)r->height;

    if (score > bestLearnedScore) {
      bestLearnedScore = score;
      huskyBestLearnedID = r->ID;
      huskyBestX = r->xCenter;
      huskyBestY = r->yCenter;
      huskyBestW = r->width;
      huskyBestH = r->height;
    }

    // --------------------------------------------------------
    // RED / GREEN PILLAR DETECTION
    // --------------------------------------------------------
    // Select the nearest valid learned pillar. The corridor state
    // then starts the adaptive pillar-avoidance maneuver.
    bool isRedPillar =
      isRedPillarID(r->ID);

    bool isGreenPillar =
      isGreenPillarID(r->ID);

    if (isRedPillar || isGreenPillar) {
      int bottomY =
        r->yCenter +
        r->height / 2;

      // FAR pillars are ignored completely.
      bool areaNear =
        area >= HUSKY_PILLAR_NEAR_MIN_AREA;

      bool yNear =
        r->yCenter >= HUSKY_PILLAR_NEAR_MIN_Y;

      bool bottomNear =
        bottomY >= HUSKY_PILLAR_NEAR_MIN_BOTTOM_Y;

      // Earlier but still reliable near-pillar gate:
      // area must be large enough, and either the center or bottom
      // of the box must already be low enough in the image.
      //
      // This avoids the previous late detection caused by waiting
      // for ALL THREE conditions at the same time.
      bool pillarNearEnough =
        areaNear &&
        (
          yNear ||
          bottomNear
        );

      if (
        pillarNearEnough
      ) {
        // Choose ONLY the nearest valid pillar.
        //
        // Largest apparent area is the primary indicator.
        // If two boxes have the same area, choose the one whose
        // bottom edge is lower in the image.
        bool nearer =
          area > bestPillarArea ||
          (
            area == bestPillarArea &&
            bottomY > bestPillarBottomY
          );

        if (nearer) {
          bestPillarArea = area;
          bestPillarBottomY = bottomY;

          frameBestPillarID = r->ID;
          frameBestPillarX = r->xCenter;
          frameBestPillarY = r->yCenter;
          frameBestPillarW = r->width;
          frameBestPillarH = r->height;
          frameBestPillarArea = area;
        }
      }

      // RED/GREEN results are never used as intersection colors.
      continue;
    }

    // --------------------------------------------------------
    // EXISTING BLUE / ORANGE INTERSECTION DETECTION
    // --------------------------------------------------------
    int direction = 0;

    if (r->ID == HUSKY_BLUE_ID)
      direction = +1;
    else if (r->ID == HUSKY_ORANGE_ID)
      direction = -1;
    else
      continue;

    if (area < HUSKY_LINE_MIN_AREA)
      continue;

    if (r->yCenter < HUSKY_LINE_MIN_Y)
      continue;

    if (score > bestIntersectionScore) {
      bestIntersectionScore = score;
      huskyBestIntersectionDirection = direction;
    }
  }

  lastGoodHuskyFrameMs = millis();

  if (frameBestPillarID != 0) {
    int bottomY =
      frameBestPillarY +
      frameBestPillarH / 2;

    // --------------------------------------------------------
    // MULTI-FRAME CONFIDENCE SCORE
    // --------------------------------------------------------
    // Same ID + stable/increasing geometry builds confidence.
    // A single bad frame cannot immediately trigger avoidance.
    if (
      frameBestPillarID ==
      pillarConfidenceID
    ) {
      pillarConfidenceScore += 2;

      // Area should normally stay similar or grow as we approach.
      if (
        pillarConfidencePrevArea <= 0 ||
        frameBestPillarArea >=
          (long)(
            pillarConfidencePrevArea *
            0.82
          )
      ) {
        pillarConfidenceScore += 1;
      }

      // Bottom of box should stay similar or move lower.
      if (
        bottomY >=
        pillarConfidencePrevBottomY - 10
      ) {
        pillarConfidenceScore += 1;
      }

      // X should not teleport across the frame.
      if (
        abs(
          frameBestPillarX -
          pillarConfidencePrevX
        ) <= 120
      ) {
        pillarConfidenceScore += 1;
      }
    }
    else {
      pillarConfidenceID =
        frameBestPillarID;

      pillarConfidenceScore = 2;
    }

    pillarConfidenceScore =
      constrain(
        pillarConfidenceScore,
        0,
        PILLAR_CONFIDENCE_MAX
      );

    pillarConfidencePrevX =
      frameBestPillarX;

    pillarConfidencePrevBottomY =
      bottomY;

    pillarConfidencePrevArea =
      frameBestPillarArea;

    huskyBestPillarID =
      frameBestPillarID;

    huskyBestPillarX =
      frameBestPillarX;

    huskyBestPillarY =
      frameBestPillarY;

    huskyBestPillarW =
      frameBestPillarW;

    huskyBestPillarH =
      frameBestPillarH;

    huskyBestPillarArea =
      frameBestPillarArea;

    lastGoodPillarFrameMs =
      millis();
  }
  else {
    // Decay confidence rather than instantly dropping it.
    if (pillarConfidenceScore > 0)
      pillarConfidenceScore -= 2;

    if (
      millis() -
      lastGoodPillarFrameMs >
      HUSKY_PILLAR_FRAME_STALE_MS
    ) {
      huskyBestPillarID = 0;
      huskyBestPillarX = 0;
      huskyBestPillarY = 0;
      huskyBestPillarW = 0;
      huskyBestPillarH = 0;
      huskyBestPillarArea = 0;

      pillarConfidenceScore = 0;
      pillarConfidenceID = 0;
    }
  }
}

bool pillarVisibleNow() {
  if (huskyBestPillarID == 0)
    return false;

  return
    millis() - lastGoodPillarFrameMs <=
    HUSKY_PILLAR_FRAME_STALE_MS;
}

const char* pillarName() {
  if (!pillarVisibleNow())
    return "NONE";

  if (isRedPillarID(huskyBestPillarID))
    return "RED";

  if (isGreenPillarID(huskyBestPillarID))
    return "GREEN";

  return "UNKNOWN";
}

void maintainSensorConnections() {
  // Intentionally disabled.
  //
  // MPU6050 calibration and HUSKYLENS initialization happen ONCE
  // in setup(). Re-running mpu.begin()/calibration can reset yaw and
  // disturb the robot during WAIT/RUN.
}

