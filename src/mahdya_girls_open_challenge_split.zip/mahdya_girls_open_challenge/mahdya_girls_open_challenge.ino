/*
  WRO Future Engineers 2026 - FINAL Open + Obstacle Challenge
  Arduino Mega 2560

  DRIVE MOTOR:
    DFRobot FIT0186 / Product 634
    GB37Y3530-12V-251R
    12V, 43.8:1 gearbox, Hall quadrature encoder
    700 encoder counts per gearbox output revolution
    Driven through BTS7960

  YAW TIMING FIX VERSION:
    - trapezoidal MPU6050 gyro integration
    - no lost yaw during UART/ultrasonic delays
    - frequent yaw sampling around slow operations

  COMMUNICATION:
    MPU6050 / GY-521 IMU -> I2C
    HUSKYLENS 2         -> UART Serial1

  This is based on the communication test that worked on your hardware.

  Required libraries:
    DFRobot_HuskylensV2
    Adafruit MPU6050
    Adafruit Unified Sensor
    Adafruit BusIO
    Wire
    Servo

  ------------------------------------------------------------
  PIN MAP
  ------------------------------------------------------------

  Encoder A              D2
  Encoder B              D3

  BTS7960 RPWM           D5
  BTS7960 LPWM           D7
  BTS7960 R_EN/L_EN      5V

  Steering servo         D9

  URM09 Front            D22
  URM09 Left             D23
  URM09 Right            D24
  URM09 Rear             D25
  URM09 Rear-Left        D27
  URM09 Rear-Right       D28

  Start button           D26 -> GND
  Buzzer                 D29

  ------------------------------------------------------------
  MPU6050 / GY-521 - I2C
  ------------------------------------------------------------

  MPU6050 SDA            Mega D20 / SDA
  MPU6050 SCL            Mega D21 / SCL
  MPU6050 VCC            5V (common GY-521 breakout)
  MPU6050 GND            GND

  Normal address         0x68
  If AD0 is HIGH         0x69

  ------------------------------------------------------------
  HUSKYLENS 2 - UART
  ------------------------------------------------------------

  HUSKYLENS TX            Mega D19 / RX1
  HUSKYLENS RX            Mega D18 / TX1
  HUSKYLENS GND           Mega GND

  HUSKYLENS Protocol:
    Serial 9600

  USB Serial Monitor:
    115200 baud

  ------------------------------------------------------------
  COLOR RECOGNITION
  ------------------------------------------------------------

  ID 0 = unlearned / white box -> ignored
  ID 1 = BLUE   -> LEFT
  ID 2 = ORANGE -> RIGHT

  After the first completed turn, the direction is permanently
  latched. Opposite-color intersections are ignored.

  3 laps = 12 turns.

  After the 12th completed turn, the robot continues straight
  with yaw + wall centering until it sees the NEXT intersection
  of the latched color, then stops.

  ------------------------------------------------------------
  SERIAL COMMANDS while WAIT or STOP
  ------------------------------------------------------------

  help
  i2c
  us
  imu
  husky
  enc
  button
  motorf
  motorb
  servol
  servoc
  servor
  buzz
  recal
  all
*/

#include <Wire.h>
#include <Servo.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <DFRobot_HuskylensV2.h>

#define VELOCITY_TEMP(temp) (((331.5 + 0.6 * (float)(temp)) * 100.0) / 1000000.0)

//
// ==========================================================
// FIT0186 + BTS7960 WIRING
// ==========================================================
//
// DFRobot FIT0186 encoder:
//   Encoder +5V  -> Mega 5V
//   Encoder GND  -> Mega GND
//   Encoder A    -> Mega D2
//   Encoder B    -> Mega D3
//
// Motor power:
//   FIT0186 motor lead 1 -> BTS7960 M+
//   FIT0186 motor lead 2 -> BTS7960 M-
//
// BTS7960 logic/power:
//   RPWM -> Mega D5
//   LPWM -> Mega D7
//   R_EN -> 5V
//   L_EN -> 5V
//   VCC  -> Mega 5V
//   GND  -> Mega GND
//   B+   -> +12V motor battery
//   B-   -> battery negative
//
// IMPORTANT: Mega GND, encoder GND, BTS7960 GND, and battery negative
// must share a common ground.
// NEVER connect the 12V motor supply to the Mega 5V pin.
//

// ===================== PINS =====================
// DFRobot FIT0186 encoder:
//   Encoder A -> Mega D2
//   Encoder B -> Mega D3
//
// BTS7960 motor driver:
//   RPWM -> Mega D5
//   LPWM -> Mega D7
//   R_EN + L_EN -> 5V
//   VCC -> 5V
//   GND -> common GND
//   B+ / B- -> 12V motor battery
//   M+ / M- -> DFRobot motor power leads
const uint8_t PIN_ENCODER_A = 2;
const uint8_t PIN_ENCODER_B = 3;
const uint8_t PIN_BTS_RPWM = 5;
const uint8_t PIN_BTS_LPWM = 7;
const uint8_t PIN_STEERING = 9;
const uint8_t PIN_US_FRONT = 22;
const uint8_t PIN_US_LEFT  = 23;
const uint8_t PIN_US_RIGHT = 24;
const uint8_t PIN_US_REAR  = 25;
const uint8_t PIN_START_BUTTON = 26;

// NEW rear-side sensors for wide rear-wheel clearance.
const uint8_t PIN_US_REAR_LEFT  = 27;
const uint8_t PIN_US_REAR_RIGHT = 28;

const uint8_t PIN_BUZZER = 29;

// ===================== TUNING =====================
unsigned long TELEMETRY_INTERVAL_MS = 100;

// ==========================================================
// ================= QUICK TUNING - START HERE ===============
// ==========================================================
//
// 1) CUMULATIVE YAW CENTERING COMPENSATION AFTER EACH TURN
//
//    Increase this if the robot keeps drifting farther to the inside
//    after every completed corner.
//
//    Typical range to test:
//      0.0 = disabled
//      2.0 = light compensation
//      2.5 = current setting
//      3.0 = stronger compensation
//
float YAW_CENTER_COMP_PER_TURN_DEG = 1.1;

//
// 2) OPEN CHALLENGE FINAL FRONT-ULTRASONIC STOP DISTANCE
//
//    Smaller value = robot stops CLOSER to the wall.
//    Larger value  = robot stops FARTHER from the wall.
//
//    Example:
//      40.0 = stop at 40 cm
//      70.0 = current setting
//      90.0 = stop farther away
//
float OPEN_FINAL_STOP_FRONT_CM = 160.0;

// ==========================================================
// =============== END QUICK TUNING SECTION =================
// ==========================================================

// ==========================================================
// ONE SWITCH: OBSTACLE CHALLENGE / OPEN CHALLENGE
// ==========================================================
//
// true  = OBSTACLE CHALLENGE:
//         pillar avoidance ON + special final parking ON
//
// false = OPEN CHALLENGE:
//         ignore RED/GREEN pillars completely
//         turn 12 is a normal corner
//         no final parking
//         after turn 12: move forward with yaw-only centering
//         for 1 second, then stop when front ultrasonic reaches
//         OPEN_FINAL_STOP_FRONT_CM.
//
// Change ONLY this variable when switching challenge type.
bool OBSTACLE_CHALLENGE_MODE = false;

unsigned long OPEN_FINAL_YAW_CENTER_MS = 1000;
int OPEN_FINAL_PWM = 180;

int DRIVE_PWM          = 255;
int APPROACH_PWM       = 150;
int TURN_PWM_FAST      = 255;
int TURN_PWM_SLOW      = 150;
int ESCAPE_BACK_PWM    = 150;
int ESCAPE_FORWARD_PWM = 150;
// DFRobot FIT0186 motor direction.
// Keep +1 when the serial command "motorf" physically drives the robot forward.
// Change ONLY this to -1 if motorf drives backward.
int MOTOR_DIRECTION    = +1;

// Encoder display/sign direction.
// Distance calculations use absolute encoder movement, so this does not
// change distance measurement. Set -1 only if you want the displayed
// encoder sign reversed.
int ENCODER_DIRECTION  = -1;

int SERVO_CENTER_DEG = 88;
// Reversed because your LEFT test went RIGHT.
int SERVO_DIRECTION = 1;
// Increased steering authority.
// With center=98 and SERVO_DIRECTION=-1, +/-50 gives a large
// correction range while keeping the commanded servo angle in range.
float MAX_STEER_DEG       = 60.0;
float CORRIDOR_MAX_STEER_DEG = 14.0;
float TURN_STEER_DEG      = 55.0;
float TEST_STEER_DEG      = 40.0;

float YAW_SIGN = +1.0;          // physical LEFT should increase yaw
float GYRO_Z_BIAS_DPS = 0.0;

// Normal MPU6050 / GY-521
// Read every ~4 ms when the main loop is free.
const unsigned long IMU_READ_INTERVAL_US = 4000UL;

// Gyro calibration at startup.
const uint16_t QUICK_GYRO_SAMPLES = 300;
const uint8_t QUICK_GYRO_DELAY_MS = 3;

// Yaw correction tuning.
// Start with 1.000. If a real 90 deg rotation reads 84 deg:
// YAW_SCALE = 90.0 / 84.0 = 1.0714
float YAW_SCALE = 1.0000;

// Suppress tiny stationary noise after bias subtraction.
// Keep small so slow real turns are still detected.
// Low enough to measure slow corridor drift.
float YAW_GYRO_DEADBAND_DPS = 0.08;

// ==========================================================
// STABLE FOUR-WHEEL-STEERING CORRIDOR CONTROL
// ==========================================================
//
// Front and rear wheels now steer together, so the robot reacts much
// more strongly to servo movement. Corridor gains and steering limits
// are intentionally much smaller than the old 2-wheel-steer setup.
float YAW_KP = 1.60;
float YAW_KD = 0.05;


// SIDE ULTRASONIC CENTERING
// Positive software steering = physical RIGHT with SERVO_DIRECTION=-1.
float WALL_KP = 0.0;  // ultrasonic centering disabled; wall avoid only
float WALL_MAX_CORRECTION_DEG = 0.0;  // centering disabled

float SIDE_VALID_MIN_CM = 3.0;
float SIDE_VALID_MAX_CM = 250.0;

// Smaller deadband = reacts sooner to side-distance difference.
float SIDE_CENTER_DEADBAND_CM = 9.0;

// HARD WALL AVOID:
// If a side wall is closer than this distance, use a strong fixed
// steering command away from it.
float WALL_AVOID_TRIGGER_CM = 10.0;
float WALL_AVOID_STEER_DEG  = 10.0;

// Four-wheel-steering stability tuning.
float FOUR_WS_YAW_DEADBAND_DEG = 0.35;
float FOUR_WS_YAW_MAX_CORRECTION_DEG = 30.0;

// ==========================================================
// MPU CUMULATIVE CORRIDOR-YAW COMPENSATION
// ==========================================================
//
// The physical corner turn remains EXACTLY 90 degrees.
//
// This changes ONLY the yaw target used for centering in the corridor
// after each completed turn.
//
// Positive value = reduce the corridor target magnitude after every turn.
// Example with LEFT (+) race and 2.5 deg compensation:
//   turn 1 ->  87.5 deg instead of  90
//   turn 2 -> 175.0 deg instead of 180
//   turn 3 -> 262.5 deg instead of 270
//
// RIGHT (-) race mirrors automatically:
//   turn 1 -> -87.5 deg
//   turn 2 -> -175.0 deg
//
// Start around 2.0 to 3.0 degrees.
// Set 0.0 to disable.
float FOUR_WS_WALL_ERROR_FILTER = 0.85;
float FOUR_WS_COMMAND_FILTER = 0.50;
float FOUR_WS_STEER_SLEW_DPS = 120.0;
float FOUR_WS_OUTPUT_DEADBAND_DEG = 0.70;
float FOUR_WS_WALL_FADE_YAW_DEG = 5.0;

// ==========================================================
// POST-TURN YAW RE-LOCK
// ==========================================================
//
// For the first part of every new corridor, increase yaw correction
// response so the 4WS chassis straightens itself immediately after
// leaving the corner.
unsigned long FOUR_WS_POST_TURN_YAW_BOOST_MS = 700;
float FOUR_WS_POST_TURN_YAW_KP_MULTIPLIER = 1.00;
float FOUR_WS_POST_TURN_YAW_KD_MULTIPLIER = 1.00;

// During the boost, allow the full corridor steering limit (14 deg).
// Normal corridor still uses the same CORRIDOR_MAX_STEER_DEG value.

// ==========================================================
// INTERNAL POST-TURN CORRIDOR RECOVERY
// ==========================================================
// Existing user tuning above is NOT changed.
//
// Corridor 1 can teach the robot the expected centered distance from
// either wall. After a turn, if one side sensor still sees the corner
// opening, the robot can keep centering from the other wall instead
// of disabling wall correction completely.
float FOUR_WS_LEARNED_SIDE_CM = 0.0;
bool FOUR_WS_HAVE_LEARNED_SIDE = false;
float FOUR_WS_SIDE_REFERENCE_FILTER = 0.92;

// Never let wall centering be multiplied all the way down to zero.
float FOUR_WS_MIN_WALL_SCALE = 0.35;

// Keep full wall-centering authority briefly after every corner.
unsigned long FOUR_WS_POST_TURN_FULL_WALL_MS = 1200;
unsigned long fourWsLastCornerCompletedMs = 0;

// For Serial telemetry.
float lastWallCorrectionDeg = 0.0;
bool wallAvoidActive = false;

float fourWsFilteredWallError = 0.0;

// Separate low-pass target from actual servo command.
// This prevents the output deadband from permanently trapping correction at 0.
float fourWsFilteredWanted = 0.0;
float fourWsFilteredSteer = 0.0;

float fourWsLastRawSteer = 0.0;
float fourWsLastHeadingCorrection = 0.0;
unsigned long fourWsLastSteerMicros = 0;

// ==========================================================
// CORNER TURN TRIGGERS
// ==========================================================
//
// After HUSKYLENS sees the intersection, the robot keeps going
// straight on the OLD yaw until a corner trigger becomes true.
//
// Encoder trigger, separately tunable for Corner 1..4:
float CORNER_FORWARD_CM[4] = {
  0.0,   // Corner 1
  50.0,   // Corner 2
  50.0,   // Corner 3
  0.0    // Corner 4
};

// FRONT ULTRASONIC TURN DISTANCE, separately tunable for Corner 1..4.
// Example: 16.0 means START THE 90-DEG TURN when front <= 16 cm.
float CORNER_FRONT_TURN_CM[4] = {
  80.0,   // Corner 1
  41.0,   // Corner 2
  41.0,   // Corner 3
  80.0    // Corner 4
};

// Keep both true to preserve the current behavior:
// turn when EITHER encoder distance OR front distance is reached.
bool USE_ENCODER_CORNER_TRIGGER = true;
bool USE_FRONT_CORNER_TRIGGER   = true;

// ==========================================================
// OPTIONAL BACKWARD DISTANCE BEFORE NORMAL CORNER TURN
// ==========================================================
//
// These 4 values repeat every lap:
//   Turn 1, 5, 9  -> index 0 / Corner 1
//   Turn 2, 6, 10 -> index 1 / Corner 2
//   Turn 3, 7, 11 -> index 2 / Corner 3
//   Turn 4, 8     -> index 3 / Corner 4
//
// NOTE:
// Turn 12 is handled by the SPECIAL FINAL PARKING sequence and
// continues to use FINAL_BACK_CM. It is intentionally NOT given
// an extra reverse here, so it does not reverse twice.
//
// Set false to disable ALL normal-corner pre-turn reversing.
bool ENABLE_BACK_BEFORE_TURN = true;

// Encoder reverse distance before each of the 4 normal corner positions.
// Set any individual value to 0.0 to disable reverse only for that corner.
float BACK_BEFORE_TURN_CM[4] = {
  0.0,   // Corner 1
  0.0,   // Corner 2
  0.0,   // Corner 3
  0.0    // Corner 4
};

// Reverse speed used only for this pre-turn movement.
int BACK_BEFORE_TURN_PWM = 150;

// Safety timeout so a bad encoder cannot leave the robot reversing forever.
unsigned long BACK_BEFORE_TURN_TIMEOUT_MS = 2000;

// ==========================================================
// SIDE OPENING REQUIRED BEFORE EACH TURN
// ==========================================================
//
// LEFT turn:
//   left ultrasonic must be >= TURN_SIDE_OPEN_MIN_CM
//
// RIGHT turn:
//   right ultrasonic must be >= TURN_SIDE_OPEN_MIN_CM
//
// The robot will keep moving forward in APPROACH until BOTH:
//   1) normal corner trigger is reached
//      (encoder and/or front ultrasonic)
//   2) the side of the intended turn is open enough
//
// Set USE_SIDE_OPEN_TURN_GATE=false to disable this condition.
bool USE_SIDE_OPEN_TURN_GATE = true;
float TURN_SIDE_OPEN_MIN_CM = 30.0;

// ==========================================================
// ULTRASONIC FALLBACK CORNER TURN
// ==========================================================
//
// Backup when HUSKYLENS misses the blue/orange intersection.
//
// Turn starts when BOTH:
//   1) front <= CORNER_FRONT_TURN_CM[current corner]
//   2) turn-side distance >= ULTRASONIC_FALLBACK_SIDE_MIN_CM
//
// Once round direction is known:
//   LEFT round  -> only LEFT side can trigger fallback.
//   RIGHT round -> only RIGHT side can trigger fallback.
//
// Before first direction is known:
//   one open side -> use it
//   both open -> use the larger side distance
bool ENABLE_ULTRASONIC_CORNER_FALLBACK = true;

// User-requested default.
float ULTRASONIC_FALLBACK_SIDE_MIN_CM = 100.0;

// Stops the same corner from immediately retriggering.
unsigned long ULTRASONIC_FALLBACK_COOLDOWN_MS = 900;

// ==========================================================
// POST-CORNER ONE-SHOT LOCK / REARM
// ==========================================================
//
// FIX FOR REPEATED/ENDLESS CORNER TURNS:
// After one 90-degree turn completes, do NOT allow the same physical
// corner to trigger another turn immediately.
//
// The corner system re-arms after:
//   - minimum time has passed,
//   - robot has moved at least CORNER_REARM_FORWARD_CM,
//   - AND the old turn-side opening has closed,
//     OR the robot has moved CORNER_REARM_FORCE_CM as a fallback.
unsigned long CORNER_REARM_MIN_MS = 600;
float CORNER_REARM_FORWARD_CM = 35.0;
float CORNER_REARM_FORCE_CM = 60.0;
float CORNER_REARM_SIDE_CLOSED_CM = 85.0;

// ==========================================================
// FINAL STOP AFTER TURN 12
// ==========================================================
//
// After the 12th completed turn the robot keeps driving with
// normal yaw + side-wall centering.
//
// It stops when:
//      front ultrasonic <= FINAL_STOP_FRONT_CM
//
// Tune this value freely.
float FINAL_STOP_FRONT_CM = 70.0;

float TURN_ANGLE_DEG = 90.0;
float TURN_TOLERANCE_DEG = 1.0;
float TURN_SLOW_ZONE_DEG = 25.0;
unsigned long TURN_SETTLE_MS = 50;
unsigned long TURN_TIMEOUT_MS = 7000;

// ==========================================================
// 4WS EXACT-CORNER TURN CALIBRATION
// ==========================================================
//
// Observed:
//   software target = 90 deg
//   physical rotation ~= 160 deg
//
// Therefore the gyro was effectively under-reading the fast turn.
// 160/90 = 1.777...
//
// This multiplier is used ONLY while a normal corner is turning.
// Corridor yaw keeps using the user's existing YAW_SCALE.
float FOUR_WS_TURN_YAW_MULTIPLIER = 1.78;

// The new 4WS chassis does not need 55 deg of actual turn steering.
// Keep TURN_STEER_DEG=55 untouched as the old/global user tune,
// but limit the actual normal-corner controller to this safer range.
float FOUR_WS_TURN_MAX_STEER_DEG = 20.0;
float FOUR_WS_TURN_MIN_STEER_DEG = 3.0;

// Start reducing steering much earlier than the old controller.
float FOUR_WS_TURN_SLOW_ZONE_DEG = 70.0;

// ==========================================================
// CORNER OVERSHOOT COMPENSATION
// ==========================================================
//
// Your chassis physically settles around 98 deg when the software waits
// for the full 90-deg yaw target. Stop the steering arc early, then let
// the post-turn yaw controller pull the robot onto the exact corridor
// target of 90 deg.
//
// Start with 8 deg because observed final heading is about 98 deg.
// Increase this if the robot still finishes above 90.
// Decrease this if it finishes below 90.
// Exact 90-degree relative corner. No intentional early stop.
float FOUR_WS_TURN_STOP_EARLY_DEG = 0.0;

// Stop motor briefly at the target instead of continuing to drive
// while the steering mechanism is still returning to center.
unsigned long FOUR_WS_TURN_BRAKE_SETTLE_MS = 140;

// Actual yaw where this physical turn starts/stops.
float cornerTurnStartYaw = 0.0;
float cornerTurnStopYaw = 0.0;

// True only during the actual corner rotation.
// updateYaw() uses the turn-only calibration multiplier when true.
bool normalCornerYawScaleActive = false;

// ==========================================================
// CORRIDOR YAW REBASE
// ==========================================================
//
// After each corner the robot continues driving immediately.
// Once it has been in the new corridor for a short time AND the yaw
// error is already very small, snap only that tiny remaining sensor
// error to the exact corridor reference.
//
// This prevents 0.5-1 degree residual gyro error from accumulating
// turn after turn without hiding a large physical heading error.
bool corridorYawRebasePending = false;
unsigned long corridorYawRebaseEarliestMs = 0;
unsigned long CORRIDOR_YAW_REBASE_DELAY_MS = 500;
float CORRIDOR_YAW_REBASE_MAX_ERROR_DEG = 1.2;

const int HUSKY_BLUE_ID   = 1;
const int HUSKY_ORANGE_ID = 2;
int HUSKY_LINE_MIN_Y = 80;
long HUSKY_LINE_MIN_AREA = 100;
unsigned long HUSKY_POLL_INTERVAL_MS = 100;   // UART 9600
unsigned long LINE_COOLDOWN_MS = 850;
unsigned long HUSKY_FRAME_STALE_MS = 350;

// ==========================================================
// PILLAR DETECTION - SAME CODE FOR OPEN + OBSTACLE
// ==========================================================
//
// Open Challenge:
//   no RED/GREEN pillar is present -> this logic does nothing.
//
// Obstacle Challenge:
//   RED/GREEN pillars are detected automatically.
//   RED pillars are avoided to the RIGHT.
//   GREEN pillars are avoided to the LEFT.
//   Multiple learned IDs can be assigned to each pillar color.
//
// MULTI-ID PILLAR TRAINING
//
// Keep your current IDs and add more learned IDs inside the braces.
//
// Example:
//   RED   -> {5, 7, 9}
//   GREEN -> {4, 6, 8}
//
// Current IDs from your file:
const int HUSKY_RED_PILLAR_IDS[] = {
  5
  ,
  3
};

const int HUSKY_GREEN_PILLAR_IDS[] = {
  4
  ,
  6
};

const uint8_t HUSKY_RED_PILLAR_ID_COUNT =
  sizeof(HUSKY_RED_PILLAR_IDS) /
  sizeof(HUSKY_RED_PILLAR_IDS[0]);

const uint8_t HUSKY_GREEN_PILLAR_ID_COUNT =
  sizeof(HUSKY_GREEN_PILLAR_IDS) /
  sizeof(HUSKY_GREEN_PILLAR_IDS[0]);

bool isRedPillarID(int id) {
  for (
    uint8_t i = 0;
    i < HUSKY_RED_PILLAR_ID_COUNT;
    i++
  ) {
    if (id == HUSKY_RED_PILLAR_IDS[i])
      return true;
  }

  return false;
}

bool isGreenPillarID(int id) {
  for (
    uint8_t i = 0;
    i < HUSKY_GREEN_PILLAR_ID_COUNT;
    i++
  ) {
    if (id == HUSKY_GREEN_PILLAR_IDS[i])
      return true;
  }

  return false;
}

// ==========================================================
// SMART PILLAR AVOIDANCE - ONLY 5 MAIN TUNES
// ==========================================================
//
// 1) DETECTION DISTANCE
// Higher = pillar must look larger -> detect later/closer.
// Lower  = detect earlier/farther.
float PILLAR_TUNE_NEAR_AREA = 1000.0;

// 2) MAXIMUM AVOIDANCE YAW
// Higher = more sideways clearance from dangerous pillars.
float PILLAR_TUNE_MAX_TURN_DEG = 50.0;

// 3) PILLAR PASS SPEED
// This is the normal upper PWM during the maneuver.
// The code automatically slows down more when danger is high.
int PILLAR_TUNE_PASS_PWM = 255;

// 4) STEERING SMOOTHNESS
// Lower = softer/slower servo changes.
// Higher = faster/more aggressive response.
float PILLAR_TUNE_SMOOTHNESS_DPS = 130.0;

// 5) REAR-WHEEL SAFETY DISTANCE
// AFTER the rear-side ultrasonic confirms the pillar has passed,
// continue this small encoder distance before returning to corridor yaw.
float PILLAR_TUNE_REAR_SAFETY_CM = 5.0;


// ==========================================================
// INTERNAL SMART-PILLAR SETTINGS
// Normally DO NOT tune below this line.
// ==========================================================

bool ENABLE_PILLAR_AVOIDANCE = true;

// RED   -> robot passes on RIGHT -> pillar is on LEFT side.
// GREEN -> robot passes on LEFT  -> pillar is on RIGHT side.

// Camera near gate.
long HUSKY_PILLAR_NEAR_MIN_AREA =
  (long)PILLAR_TUNE_NEAR_AREA;

int HUSKY_PILLAR_NEAR_MIN_Y = 115;
int HUSKY_PILLAR_NEAR_MIN_BOTTOM_Y = 165;
unsigned long HUSKY_PILLAR_FRAME_STALE_MS = 180;

// Camera confidence:
// pillar must be geometrically consistent over multiple frames.
int PILLAR_CONFIDENCE_TRIGGER = 2;
int PILLAR_CONFIDENCE_MAX = 12;

// X-position calibration.
float PILLAR_RED_NO_AVOID_X = 180.0;
float PILLAR_RED_FULL_AVOID_X = 430.0;

float PILLAR_GREEN_NO_AVOID_X = 500.0;
float PILLAR_GREEN_FULL_AVOID_X = 350.0;

// Close visual cues only BOOST an already dangerous X position.
long PILLAR_FORCE_AVOID_AREA = 800;
int PILLAR_FORCE_AVOID_HEIGHT = 55;
int PILLAR_FORCE_AVOID_BOTTOM_Y = 190;

float PILLAR_CLOSE_BOOST_START_SEVERITY = 0.25;
float PILLAR_CLOSE_SEVERITY_BOOST = 0.25;

// Keep the short stop before the maneuver.
bool PILLAR_STOP_BEFORE_AVOID = true;
unsigned long PILLAR_STOP_MS = 120;

// Avoidance yaw.
float PILLAR_MIN_TURN_OUT_DEG =
  PILLAR_TUNE_MAX_TURN_DEG * 0.10;

float PILLAR_MAX_TURN_OUT_DEG =
  PILLAR_TUNE_MAX_TURN_DEG;

float PILLAR_SKIP_BELOW_DEG = 7.0;

// Smooth steering.
float PILLAR_TURN_STEER_DEG = 50.0;
float PILLAR_TURN_MIN_STEER_DEG = 12.0;
float PILLAR_TURN_SLOW_ZONE_DEG = 25.0;

float PILLAR_STEER_SLEW_DEG_PER_SEC =
  PILLAR_TUNE_SMOOTHNESS_DPS;

// Adaptive speed.
// High danger slows the robot automatically.
int PILLAR_SPEED_MAX_PWM =
  PILLAR_TUNE_PASS_PWM;

int PILLAR_SPEED_MIN_PWM =
  (int)(PILLAR_TUNE_PASS_PWM * 0.68);

// Side-ultrasonic automatic pass detection.
// No fixed "pillar distance" is required.
float PILLAR_SIDE_ENTER_RATIO = 0.82;
float PILLAR_SIDE_EXIT_RATIO = 1.45;
int PILLAR_SIDE_CONFIRM_READS = 3;

// Require a meaningful drop from the starting wall/background distance
// before deciding a side sensor has actually seen the pillar.
float PILLAR_SIDE_MIN_DROP_CM = 4.0;

// Rear wheel protection.
float PILLAR_REAR_SAFETY_CM =
  PILLAR_TUNE_REAR_SAFETY_CM;

// Encoder fallback only if a side sensor is unavailable/noisy.
float PILLAR_PASS_FALLBACK_CM = 4.0;

// Yaw-only correction while beside the pillar.
float PILLAR_YAW_KP = 4.20;
float PILLAR_YAW_KD = 0.10;
float PILLAR_FORWARD_MAX_STEER_DEG = 50.0;

float PILLAR_YAW_TOLERANCE_DEG = 3.0;
unsigned long PILLAR_TURN_TIMEOUT_MS = 3500;
unsigned long PILLAR_PASS_TIMEOUT_MS = 5000;
unsigned long PILLAR_COOLDOWN_MS = 1200;
unsigned long PILLAR_SAFE_RECHECK_MS = 120;


float ULTRASONIC_TEMP_C = 20.0;
unsigned long URM09_PULSE_TIMEOUT_US = 18000UL;
unsigned long SONAR_SLOT_INTERVAL_MS = 12;
float SONAR_FILTER_OLD_WEIGHT = 0.15;

// ==========================================================
// DFRobot FIT0186 ENCODER / DISTANCE CALIBRATION
// ==========================================================
//
// Motor: DFRobot FIT0186 / GB37Y3530-12V-251R
// Gear ratio: 43.8:1
// Encoder starting calibration: approximately 700 counts/output revolution.
//
// This version counts only the RISING edge of encoder A.
// Wheel diameter measured on this robot: 70 mm = 7.0 cm.
//
// Distance formula:
//   countsPerCM = ENCODER_COUNTS_PER_WHEEL_REV / (PI * WHEEL_DIAMETER_CM)
//
// If a measured floor test is still off, tune only the CPR using:
//   NEW_CPR = CURRENT_CPR * commanded_cm / actual_cm
//
float ENCODER_COUNTS_PER_WHEEL_REV = 700.0;
float WHEEL_DIAMETER_CM = 7.0;

// Reference only; these do not change the control algorithm.
const float DFROBOT_FIT0186_GEAR_RATIO = 43.8;
const float DFROBOT_FIT0186_NO_LOAD_RPM = 251.0;
const float DFROBOT_FIT0186_ENCODER_CPR = 700.0;

int STUCK_MIN_MOTOR_PWM = 90;
unsigned long STUCK_CHECK_WINDOW_MS = 500;
long STUCK_MIN_ENCODER_COUNTS = 3;
float ESCAPE_BACK_CM = 10.0;
float ESCAPE_FORWARD_CM = 14.0;
float ESCAPE_STEER_DEG = 18.0;
unsigned long ESCAPE_BACK_TIMEOUT_MS = 1600;
unsigned long ESCAPE_FORWARD_TIMEOUT_MS = 1800;

int TOTAL_TURNS = 12;

// ==========================================================
// PARKING EXIT + FINAL PARKING
// ==========================================================
//
// Direction is determined BEFORE moving:
//   LEFT ultrasonic > RIGHT ultrasonic -> LEFT race (+1)
//   RIGHT ultrasonic > LEFT ultrasonic -> RIGHT race (-1)
//
// Straight parking movements use encoder distance.
// Parking/final alignment uses yaw only: NO wall centering.

// ---------- Start behavior ----------
//
// NO parking-escape routine.
// After Start:
//   - yaw is reset to 0
//   - robot drives straight with yaw correction
//   - BLUE camera marker decides LEFT first turn
//   - ORANGE camera marker decides RIGHT first turn
//
// The race direction is therefore learned from the first camera corner,
// not from the side ultrasonics.

// ---------- Special final corner / parking ----------
float FINAL_WALL_FRONT_CM = 90.0;

// After reaching 5 cm from the wall, reverse this encoder distance.
float FINAL_BACK_CM = 35.0;
int FINAL_BACK_PWM = 150;

// This IS the final normal corner turn.
float FINAL_CORRIDOR_TURN_DEG = 90.0;

// After the final 90-degree turn:
// go forward with YAW ONLY until front <= this value.
float FINAL_CENTER_FRONT_CM = 250.0;

// Small S-curve/positioning maneuver before parking.
// Default direction is opposite to the normal corner direction.
// Change -1 to +1 if your physical parking is on the other side.
float FINAL_SHIFT_ANGLE_DEG = 0.0;

// After reaching the 45-degree shift angle, move forward this
// encoder distance WHILE HOLDING the 45-degree yaw.
float FINAL_SHIFT_FORWARD_CM = 25.0;

// SAME direction as race:
// LEFT race -> 45 LEFT
// RIGHT race -> 45 RIGHT
int FINAL_SHIFT_DIRECTION_MULTIPLIER = +1;

// After returning to the main corridor yaw, move this encoder distance.
float FINAL_BEFORE_PARK_CM = 0.0;

// Turn into the parking slot in the OPPOSITE direction:
// LEFT race -> parking entry RIGHT
// RIGHT race -> parking entry LEFT
float FINAL_PARK_ENTRY_DEG = 90.0;
int FINAL_PARK_ENTRY_DIRECTION_MULTIPLIER = -1;

// Stop inside parking when front <= this distance.
float FINAL_PARK_STOP_FRONT_CM = 10.0;

int FINAL_APPROACH_PWM = 160;
int FINAL_FORWARD_PWM = 160;
int FINAL_TURN_PWM = 165;

float FINAL_YAW_KP = 4.0;
float FINAL_YAW_MAX_STEER_DEG = 35.0;

float FINAL_TURN_MIN_STEER_DEG = 16.0;
float FINAL_TURN_MAX_STEER_DEG = 45.0;
float FINAL_TURN_SLOW_ZONE_DEG = 25.0;
float FINAL_TURN_TOLERANCE_DEG = 3.0;

// ===================== OBJECTS =====================
Servo steeringServo;
HuskylensV2 huskylens;
Adafruit_MPU6050 mpu;

// ===================== STATES =====================
enum RobotState {
  STATE_WAIT_START,

  STATE_CORRIDOR,
  STATE_APPROACH_CORNER,
  STATE_PRE_TURN_BACK,
  STATE_TURNING,
  STATE_ESCAPE_BACK,
  STATE_ESCAPE_FORWARD,

  // Pillar avoidance states
  STATE_PILLAR_STOP,
  STATE_PILLAR_TURN_OUT,
  STATE_PILLAR_FORWARD,
  STATE_PILLAR_RETURN_YAW,

  // Special final corner + return to parking
  STATE_FINAL_TO_WALL,
  STATE_FINAL_BACK,
  STATE_FINAL_CORRIDOR_TURN,
  STATE_FINAL_CENTER_FORWARD,
  STATE_FINAL_SHIFT_TURN,
  STATE_FINAL_SHIFT_FORWARD,
  STATE_FINAL_RETURN_MAIN_YAW,
  STATE_FINAL_BEFORE_PARK,
  STATE_FINAL_PARK_ENTRY_TURN,
  STATE_FINAL_PARK_FORWARD,

  // Open Challenge final straight/stop.
  STATE_OPEN_FINAL_FORWARD,

  // Kept for compatibility; special final parking replaces old behavior.
  STATE_FINAL_FIND_INTERSECTION,

  STATE_STOPPED
};
RobotState state = STATE_WAIT_START;
RobotState stateBeforeEscape = STATE_CORRIDOR;

// ===================== FINAL PARK GLOBALS =====================
// Set from the first camera-detected corner:
//   +1 = LEFT race (BLUE)
//   -1 = RIGHT race (ORANGE)
int parkingDirection = 0;

// Final parking sequence
float finalPreCornerYaw = 0.0;
float finalMainCorridorYaw = 0.0;
float finalShiftYaw = 0.0;
float finalParkEntryYaw = 0.0;

int finalShiftDirection = 0;
int finalParkEntryDirection = 0;

long finalStageStartTicks = 0;

unsigned long openFinalStartMs = 0;
float openFinalYaw = 0.0;

// Forward declaration because ultrasonic fallback can start the
// special final sequence before its full function definition.
void startFinalParkingSequence();

bool imuOK = false;
bool huskyOK = false;
unsigned long lastReconnectAttemptMs = 0;

// ===================== ENCODER =====================
volatile long encoderTicks = 0;
